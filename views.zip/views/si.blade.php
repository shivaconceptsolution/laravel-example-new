<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/si" method="post">
    <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
       
      <p> <input type="radio" name="type" value="SI"   />SI  <input type="radio" name="type" value="CI"   />CI</p>
      <p><input type="checkbox" name="chk" value="Qt" /> QT <input type="checkbox" name="chk1" value="Hy" /> Hy</p>
       <p><input type="text" name="txtp" placeholder="Enter P"  /></p>
       <p><input type="text" name="txtr" placeholder="Enter R"  /></p>
       <p><input type="text" name="txtt" placeholder="Enter T"  /></p>
       <p><input type="submit" name="btnsubmit" value="Calculate" /> </p>
    </form>

    <?php
      echo @$res."<br>";
      echo "type is ".@$type;
      echo $mode;
  
    ?>
</body>
</html>