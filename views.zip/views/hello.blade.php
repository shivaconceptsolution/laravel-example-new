<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="second" method="get">
<input type="text" placeholder="Enter First Number" name="txtnum1" />
<br>
<input type="text" placeholder="Enter Second Number" name="txtnum2"  />
<br>
<input type="submit" name="btnsubmit" value="click" />
</form>


</body>
</html>